//English translation of all output to userfor the subsplus_asset plugin

CKEDITOR.lang['en']['subsplus_asset.Label'] = 'Insert or Upload Document';
CKEDITOR.lang['en']['subsplus_asset.Title'] = 'Insert or Upload Document';
CKEDITOR.lang['en']['subsplus_asset.CurrDocLink'] = 'Current Document Link';
CKEDITOR.lang['en']['subsplus_asset.UploadDoc'] = 'Upload Document';

CKEDITOR.lang['en']['subsplus_asset.ChooseHTMLStrong'] = 'Tick the item';
CKEDITOR.lang['en']['subsplus_asset.ChooseHTML'] = 'you want to insert into the pluset';
CKEDITOR.lang['en']['subsplus_asset.BeforeRadioButtonsLoad'] = 'getting existing files...';
CKEDITOR.lang['en']['subsplus_asset.BeforeRadioButtonsChange'] = 'refreshing existing files...';

CKEDITOR.lang['en']['subsplus_asset.LinkTextStrong'] = 'Add Link Text';
CKEDITOR.lang['en']['subsplus_asset.LinkText'] = 'for your document. (If you leave it blank, it will be the file name.)';

CKEDITOR.lang['en']['subsplus_asset.UploadAFileStrong'] = 'Upload a file';
CKEDITOR.lang['en']['subsplus_asset.UploadAFile'] = 'to your asset folder';

CKEDITOR.lang['en']['subsplus_asset.UploaderError'] = 'Error! Retuned message';
CKEDITOR.lang['en']['subsplus_asset.ValidateRadio'] = 'A file must be selected!';