//Spanish translation of all output to user for the subsplus_asset plugin

CKEDITOR.lang['es']['subsplus_asset.Label'] = 'Insertar o Cargar Documento';
CKEDITOR.lang['es']['subsplus_asset.Title'] = 'Insertar o Cargar Documento';
CKEDITOR.lang['es']['subsplus_asset.CurrDocLink'] = 'V&igravenculo De Documento';
CKEDITOR.lang['es']['subsplus_asset.UploadDoc'] = 'Agregar Documento';

CKEDITOR.lang['es']['subsplus_asset.ChooseHTMLStrong'] = 'Elija elemento';
CKEDITOR.lang['es']['subsplus_asset.ChooseHTML'] = 'que desea insertar';
CKEDITOR.lang['es']['subsplus_asset.BeforeRadioButtonsLoad'] = 'cargando los archivos...';
CKEDITOR.lang['es']['subsplus_asset.BeforeRadioButtonsChange'] = 'recargando los archivos...';

CKEDITOR.lang['es']['subsplus_asset.LinkTextStrong'] = 'Agregar texto del vinculo';
CKEDITOR.lang['es']['subsplus_asset.LinkText'] = 'para el documento. (Si lo deja en blanco, ser&agrave el nombre del archivo.)';

CKEDITOR.lang['es']['subsplus_asset.UploadAFileStrong'] = 'Subir un archivo';
CKEDITOR.lang['es']['subsplus_asset.UploadAFile'] = 'a su carpeta';

CKEDITOR.lang['es']['subsplus_asset.UploaderError'] = 'Error! Mensaje devuelto';
CKEDITOR.lang['es']['subsplus_asset.ValidateRadio'] = 'Un archivo debe ser seleccionado!';