//English translation of all output to userfor the subsplus_resource plugin

CKEDITOR.lang['en']['subsplus_toc.title'] = 'Table of Contents';

CKEDITOR.lang['en']['subsplus_toc.InstructionsStrong1'] = 'Check desired links.';