//Spanish translation of all output to user for the subsplus_resource plugin

CKEDITOR.lang['es']['subsplus_resource.Label'] = 'Insertar Contador de Recurso';
CKEDITOR.lang['es']['subsplus_resource.title'] = 'Insertar Contador de Recurso';

CKEDITOR.lang['es']['subsplus_resource.InstructionsStrong1'] = 'Buscar';
CKEDITOR.lang['es']['subsplus_resource.Instructions1'] = 'por un recurso guardado en SubjectsPlus';
CKEDITOR.lang['es']['subsplus_resource.InstructionsStrong2'] = 'Elegir';
CKEDITOR.lang['es']['subsplus_resource.Instructions2'] = 'el bot&ograven junto al recurso que desee y haga clic en OK (abajo)';
CKEDITOR.lang['es']['subsplus_resource.Button'] = 'Buscar';
CKEDITOR.lang['es']['subsplus_resource.IconsCheckbox'] = 'Incluye iconos?'
CKEDITOR.lang['es']['subsplus_resource.DescCheckbox'] = 'Incluye la descripci&ograven?'
CKEDITOR.lang['es']['subsplus_resource.ValidateRadio'] = 'Ning&ugraven recurso elegido!';