//English translation of all output to userfor the subsplus_resource plugin

CKEDITOR.lang['en']['subsplus_sub_spe.title'] = 'Subject Specialists';

CKEDITOR.lang['en']['subsplus_sub_spe.InstructionsStrong1'] = 'Check which staff you want to add and click save.';