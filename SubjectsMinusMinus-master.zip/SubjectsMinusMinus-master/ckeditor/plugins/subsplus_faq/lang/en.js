//English translation of all output to userfor the subsplus_faq plugin

CKEDITOR.lang['en']['subsplus_faq.Label'] = 'Insert FAQs';
CKEDITOR.lang['en']['subsplus_faq.title'] = 'Insert FAQs';

CKEDITOR.lang['en']['subsplus_faq.BySubjectLink'] = 'Browse by Subject';
CKEDITOR.lang['en']['subsplus_faq.ByCollectionLink'] = 'Browse by Collection';
CKEDITOR.lang['en']['subsplus_faq.ValidateCheckbox'] = 'No FAQs selected!';