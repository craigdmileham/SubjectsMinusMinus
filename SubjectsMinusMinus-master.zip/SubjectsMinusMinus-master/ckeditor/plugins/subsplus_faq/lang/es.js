//Spanish translation of all output to userfor the subsplus_faq plugin

CKEDITOR.lang['es']['subsplus_faq.Label'] = 'Meter FAQs';
CKEDITOR.lang['es']['subsplus_faq.title'] = 'Meter FAQs';

CKEDITOR.lang['es']['subsplus_faq.BySubjectLink'] = 'Explorar por Tema';
CKEDITOR.lang['es']['subsplus_faq.ByCollectionLink'] = 'Explorar por Coleccion';
CKEDITOR.lang['es']['subsplus_faq.ValidateCheckbox'] = 'Ningun FAQs seleccionada!';