<!--end maincontent div -->
</div>
<br />
<!--end wrap div -->
</div>
</body>
</html>

<?php
// add our shared jquery .js file

//print "<script type=\"text/javascript\" src=\"$AssetPath" . "jquery/shared.js\"></script>\n";

?>
